# 配置集中管理

import os

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret")
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "sqlite:///urls.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SHORT_URL_EXPIRE_DAYS = int(os.getenv("SHORT_URL_EXPIRE_DAYS", "30"))
    HASH_SALT = os.getenv("HASH_SALT", "please-change-this")
    HASH_MIN_LEN = int(os.getenv("HASH_MIN_LEN", "6"))


