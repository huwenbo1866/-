# 短码生成、统一返回格式、原编码函数保留

# app/utils.py
from flask import jsonify, current_app
from hashids import Hashids
import base62

def encode_id_with_hashid(n: int) -> str:
    """使用 hashids（salt + 最小长度）把自增 id 编成短码"""
    salt = current_app.config.get("HASH_SALT", "please-change-this")
    min_len = current_app.config.get("HASH_MIN_LEN", 6)
    h = Hashids(salt=salt, min_length=min_len)
    return h.encode(n)

def base62_encode_str(s: str) -> str:
    """原来你写的把字符串编码为 base62（保留做参考）"""
    num = int.from_bytes(s.encode('utf-8'), 'big') if s else 0
    return base62.encode(num)

def base62_decode_str(s: str) -> str:
    num = base62.decode(s)
    decoded_bytes = num.to_bytes((num.bit_length() + 7) // 8, 'big') if num != 0 else b''
    return decoded_bytes.decode('utf-8')

# 统一返回格式
def success_response(data=None, message="success", status_code=200):
    payload = {"status": "success", "message": message, "data": data}
    return jsonify(payload), status_code

def error_response(message="error", status_code=400):
    payload = {"status": "error", "message": message}
    return jsonify(payload), status_code








