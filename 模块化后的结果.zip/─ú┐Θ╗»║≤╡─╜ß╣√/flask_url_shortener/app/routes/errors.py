# 全局错误处理 （返回JSON格式）

from flask import Blueprint, jsonify, request, make_response
from werkzeug.exceptions import HTTPException
from datetime import datetime, timezone

bp = Blueprint("errors", __name__)

@bp.app_errorhandler(Exception)
def handle_error(e):
    # 如果是 HTTPException，返回自带的 code 和 message
    if isinstance(e, HTTPException):
        respond = jsonify({
            "error": e.name,
            "message": str(e.description),
            "status_code": e.code,
            "path": request.path,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        return make_response(respond,e.code)
    # 非 HTTPException -> 内部错误 500
    respond = jsonify({
        "error": "InternalServerError",
        "message": str(e),
        "status_code": 500,
        "path": request.path,
        "timestamp": datetime.now(timezone.utc).isoformat()
    })
    return make_response(respond, 500)