
from flask import Blueprint
from app.models import URLMap
from app import db
from app.utils import success_response, error_response
from datetime import datetime, timezone

bp = Blueprint("stats", __name__)

@bp.route("/stats/<short_code>")
def stats(short_code):
    entry = URLMap.query.filter_by(short_code=short_code).first()
    if not entry:
        return error_response("Short URL not found", 404)
    if entry.outdate_after and entry.outdate_after.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        db.session.delete(entry)
        db.session.commit()
        return error_response("URL expired", 410)
    data = {
        "original_url": entry.original_url,
        "short_code": entry.short_code,
        "clicks": entry.clicks,
        "created_at": entry.created_at.isoformat(),
        "outdate_after": entry.outdate_after.isoformat() if entry.outdate_after else None
    }
    return success_response(data=data)

@bp.route("/registered_short_urls")
def registered_short_urls():
    all_entries = URLMap.query.all()
    result = []
    for e in all_entries:
        if e.outdate_after and e.outdate_after.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
            # 跳过或根据需求删除过期项
            continue
        result.append({
            "id": e.id,
            "original_url": e.original_url,
            "short_code": e.short_code,
            "created_at": e.created_at.isoformat(),
            "outdate_after": e.outdate_after.isoformat() if e.outdate_after else None,
            "clicks": e.clicks
        })
    return success_response(data=result)
