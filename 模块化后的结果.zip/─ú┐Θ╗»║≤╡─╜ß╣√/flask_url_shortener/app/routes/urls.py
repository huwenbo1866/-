# app/routes/urls.py
from flask import Blueprint, request, redirect, render_template, current_app
from app import db
from app.models import URLMap
from app.utils import encode_id_with_hashid, success_response, error_response
from datetime import datetime, timezone

bp = Blueprint("urls", __name__)

@bp.route("/")  # 会默认从 template 目录下查找 index.html
def index():
    return render_template("index.html", short_url=request.args.get("short_url"))

@bp.route("/shorten", methods=["POST"])
def shorten_url():
    # 兼容 JSON 和表单
    if request.is_json:
        data = request.get_json()
        original_url = data.get("original_url")
        favor_short_url = data.get("short_url")
    else:
        original_url = request.form.get("original_url")
        favor_short_url = request.form.get("your_favor_short_url")

    if not original_url:
        return error_response("original_url required", 400)

    existing = URLMap.query.filter_by(original_url=original_url).first()
    if existing:
        # 如果用户指定了自定义短码但与现有不同 -> 冲突
        if favor_short_url and favor_short_url != existing.short_code:
            return error_response("Short URL already exists", 409)
        # 判断是否过期（过期的话我们删除并继续创建流程）
        if existing.outdate_after and existing.outdate_after.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
            db.session.delete(existing)
            db.session.commit()
        else:
            short_url = request.host_url.rstrip("/") + "/" + existing.short_code
            return success_response({"short_url": short_url})

    # 先插入一条，拿到 id 再生成短码（避免碰撞）
    new_entry = URLMap(original_url=original_url)
    db.session.add(new_entry)
    db.session.commit()  # 此时 new_entry.id 可用

    if favor_short_url:
        # 检查自定义短码是否冲突
        conflict = URLMap.query.filter_by(short_code=favor_short_url).first()
        if conflict:
            db.session.delete(new_entry)
            db.session.commit()
            return error_response("Short URL already exists", 409)
        new_entry.short_code = favor_short_url
    else:
        # 使用 id -> hashid 的方式生成短码
        short_code = encode_id_with_hashid(new_entry.id)
        # 保险起见检查重复（极小概率）
        if URLMap.query.filter_by(short_code=short_code).first():
            # 发生冲突：直接用 base62（退路），并在后面可改进
            short_code = short_code + "-" + str(new_entry.id)
        new_entry.short_code = short_code

    db.session.commit()
    short_url = request.host_url.rstrip("/") + "/" + new_entry.short_code

    # 如果是表单提交，跳回首页显示 short_url
    if not request.is_json:
        return redirect(f"/?short_url={short_url}")
    return success_response(data={"short_url": short_url}, status_code=201)

@bp.route("/<short_code>")
def redirect_url(short_code):
    entry = URLMap.query.filter_by(short_code=short_code).first()
    if not entry:
        return error_response("URL NotFound", 404)

    # 过期检查
    if entry.outdate_after and entry.outdate_after.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        db.session.delete(entry)
        db.session.commit()
        return error_response("URL expired", 410)

    entry.clicks = (entry.clicks or 0) + 1
    db.session.commit()

    target = entry.original_url
    if not target.startswith(("http://", "https://")):
        target = "http://" + target
    return redirect(target, code=302)
