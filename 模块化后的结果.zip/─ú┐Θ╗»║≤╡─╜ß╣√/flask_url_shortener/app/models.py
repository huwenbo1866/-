# app/models.py
from app import db
from datetime import datetime, timezone, timedelta

class URLMap(db.Model):
    __tablename__ = "url_map"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    original_url = db.Column(db.String(1024), unique=True, nullable=False)
    short_code = db.Column(db.String(128), unique=True, nullable=True)
    clicks = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    outdate_after = db.Column(db.DateTime(timezone=True),
                               default=lambda: datetime.now(timezone.utc) + timedelta(days=30),
                               nullable=True)
    def __init__(self, original_url: str, short_code: str = "temp"):
        self.original_url = original_url
        self.short_code = short_code

    def __repr__(self):
        return f"<URLMap id={self.id} short_code={self.short_code} url={self.original_url}>"
