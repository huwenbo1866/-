# 初始化 db、migrate、注册蓝图

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

db = SQLAlchemy()
migrate = Migrate()

def create_app(config_class="app.config.Config"):
    app = Flask(__name__, template_folder="templates")
    app.config.from_object(config_class)

    db.init_app(app)
    migrate.init_app(app, db)

    # 在 app 初始化后再注册蓝图，减少循环导入风险
    from app.routes.urls import bp as urls_bp
    from app.routes.stats import bp as stats_bp
    from app.routes.errors import bp as errors_bp

    app.register_blueprint(urls_bp)
    app.register_blueprint(stats_bp)
    app.register_blueprint(errors_bp)

    return app


